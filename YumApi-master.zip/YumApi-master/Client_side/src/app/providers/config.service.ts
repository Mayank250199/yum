export class Config {
    path = "https://localhost:44355";
}