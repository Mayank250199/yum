﻿namespace YumApi.Repository
{
    public class CartIngredientsRepository
    {
    }
}
