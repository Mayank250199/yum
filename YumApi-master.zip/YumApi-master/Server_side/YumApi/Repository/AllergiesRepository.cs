﻿using YumApi.Interfaces;

namespace YumApi.Repository
{
    public class AllergiesRepository : IAllergyRepository
    {

    }
}
