﻿namespace YumApi.Repository
{
    public class IngredientRepository
    {
    }
}
