﻿namespace YumApi.Models
{
    public class Nutrition
    {
        public int Id { get; set; }

        public string NutritionName { get; set; }

    }
}
