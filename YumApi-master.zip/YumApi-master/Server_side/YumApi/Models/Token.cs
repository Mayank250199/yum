﻿namespace YumApi.Models
{
    public class Token
    {
        public User User { get; set; }
        public string User_Token { get; set; }

    }
}
