﻿namespace YumApi.Interfaces
{
    public interface IAllergyRepository
    {

    }
}
